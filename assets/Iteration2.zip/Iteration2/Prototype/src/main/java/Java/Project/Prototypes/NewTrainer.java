package Java.Project.Prototypes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class NewTrainer {

	private JFrame frame;
	private JTextField FN;
	private JTextField LN;
	private JTextField E;
	private JPasswordField PWD;
	private JTextField UN;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewTrainer window = new NewTrainer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}/*

	/**
	 * Create the application.
	 */
	public NewTrainer() {
		initialize();
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(false); //initially false
		
		JTextPane txtpnNewTrainer = new JTextPane();
		txtpnNewTrainer.setEditable(false);
		txtpnNewTrainer.setText("New Trainer");
		txtpnNewTrainer.setBounds(308, 39, 85, 22);
		frame.getContentPane().add(txtpnNewTrainer);
		
		JTextPane txtpnFirstName = new JTextPane();
		txtpnFirstName.setEditable(false);
		txtpnFirstName.setText("First Name:");
		txtpnFirstName.setBounds(127, 105, 146, 22);
		frame.getContentPane().add(txtpnFirstName);
		
		FN = new JTextField();
		FN.setBounds(308, 105, 269, 22);
		frame.getContentPane().add(FN);
		FN.setColumns(10);
		
		JTextPane txtpnLastName = new JTextPane();
		txtpnLastName.setEditable(false);
		txtpnLastName.setText("Last Name: ");
		txtpnLastName.setBounds(127, 138, 146, 22);
		frame.getContentPane().add(txtpnLastName);
		
		JTextPane textthing = new JTextPane();
		textthing.setText("Username: ");
		textthing.setEditable(false);
		textthing.setBounds(127, 169, 146, 22);
		frame.getContentPane().add(textthing);
		
		UN = new JTextField();
		UN.setColumns(10);
		UN.setBounds(308, 169, 269, 22);
		frame.getContentPane().add(UN);
		
		JTextPane txtpnEmail = new JTextPane();
		txtpnEmail.setEditable(false);
		txtpnEmail.setText("Email: ");
		txtpnEmail.setBounds(127, 239, 146, 22);
		frame.getContentPane().add(txtpnEmail);
		
		JTextPane txtpnPassword = new JTextPane();
		txtpnPassword.setEditable(false);
		txtpnPassword.setText("Password: ");
		txtpnPassword.setBounds(127, 204, 146, 22);
		frame.getContentPane().add(txtpnPassword);
		
		LN = new JTextField();
		LN.setBounds(308, 138, 269, 22);
		frame.getContentPane().add(LN);
		LN.setColumns(10);
		
		E = new JTextField();
		E.setBounds(308, 239, 269, 22);
		frame.getContentPane().add(E);
		E.setColumns(10);
		
		PWD = new JPasswordField();
		PWD.setBounds(308, 204, 269, 22);
		frame.getContentPane().add(PWD);

		JTextPane txtpnSport = new JTextPane();
		txtpnSport.setEditable(false);
		txtpnSport.setText("Sport:");
		txtpnSport.setBounds(127, 274, 146, 22);
		frame.getContentPane().add(txtpnSport);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(308, 274, 269, 22);
		comboBox.addItem("Football");
		comboBox.addItem("Baseball");
		comboBox.addItem("Basketball");
		comboBox.addItem("Soccer");
		comboBox.addItem("Volleyball");
		frame.getContentPane().add(comboBox);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = new File("Data.csv");
				String out = "";
				Scanner scan;
				try {
					scan = new Scanner(file);
					while(scan.hasNextLine()) {
						out += scan.nextLine();
						out += "\n";
					}
					out += FN.getText() + ",";
					out += LN.getText() + ",";
					out += UN.getText() + ",";
					out += PWD.getText() + ",";
					out += "Trainer,";
					out += E.getText() + ",";
					out += comboBox.getItemAt(comboBox.getSelectedIndex()) + "\n";
					scan.close();
					FileWriter f;
					try {
						f = new FileWriter(file);
						f.write(out);
						f.flush();
						f.close();	
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}				
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				HeadTrainerTrainers htt = new HeadTrainerTrainers();
				htt.setVisibility(true);
				frame.dispose();
			}
		});
		btnSubmit.setBounds(210, 390, 97, 25);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerTrainers htt = new HeadTrainerTrainers();
				htt.setVisibility(true);
				frame.dispose();
			}
		});
		btnCancel.setBounds(394, 390, 97, 25);
		frame.getContentPane().add(btnCancel);
		
	}
}

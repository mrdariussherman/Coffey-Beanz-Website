package Java.Project.Prototypes;

import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class IRWatchlist {

	private JFrame frame;
	private JTextField txtSearch;
	private DefaultListModel<String> iw = new DefaultListModel<String>();

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TrainerAthletes window = new TrainerAthletes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public IRWatchlist() {
		getIRWatchs();
		initialize();
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}
	
	public void getIRWatchs() {
		File file = new File("Data.csv");
		try {
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] arr = line.split(",");
				if(arr[4].equals("Athlete") && !arr[9].equals("Cleared")) {
					iw.addElement(arr[0] + " " + arr[1] + " (" + arr[8] + ") - " + arr[9]);
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(false);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnAthletes = new JTextPane();
		txtpnAthletes.setEditable(false);
		txtpnAthletes.setText("Injury Reserved & Watchlist Athletes");
		txtpnAthletes.setBounds(191, 51, 319, 22);
		frame.getContentPane().add(txtpnAthletes);
		
		txtSearch = new JTextField();
		txtSearch.setText("Search");
		txtSearch.setBounds(532, 13, 116, 22);
		frame.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		JList list = new JList();
		list.setBounds(191, 88, 319, 337);
		list.setModel(iw);
		frame.getContentPane().add(list);
		
		JButton btnNewButton = new JButton("Okie Dokie");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnNewButton.setBounds(290, 449, 123, 23);
		frame.getContentPane().add(btnNewButton);
	}

}

package Java.Project.Prototypes;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

public class PlayerHome {

	private JFrame frame;
	private JTextPane EC;
	private JTextPane ECN;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlayerHome window = new PlayerHome();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}/*

	/**
	 * Create the application.
	 */
	public PlayerHome(String name) {
		String[] info = getInfo(name);
		initialize(info);
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}
	
	public String[] getInfo(String name) {
		File file = new File("Data.csv");
		try {
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] arr = line.split(",");
				if(arr[0].equals(name)) {
					return arr;
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String[] info) {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(false); //initially false
		
		/*JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(681, 0, 21, 503);
		frame.getContentPane().add(scrollBar);
		JScrollPane scrollPane = new JScrollPane(frame);
		scrollPane.setPreferredSize(new Dimension(720,550));*/
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		mntmHome.setBackground(Color.LIGHT_GRAY);
		mntmHome.setSelected(true);
		menuBar.add(mntmHome);
		
		JMenuItem mntmMedicalInfo = new JMenuItem("Medical Info");
		mntmMedicalInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlayerMedStuff pms = new PlayerMedStuff(info[0]);
				pms.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmMedicalInfo);
		
		JTextPane FN = new JTextPane();
		FN.setEditable(false);
		FN.setText(info[0]);
		FN.setBounds(45, 66, 123, 22);
		frame.getContentPane().add(FN);
		
		JTextPane LN = new JTextPane();
		LN.setEditable(false);
		LN.setText(info[1]);
		LN.setBounds(219, 66, 123, 22);
		frame.getContentPane().add(LN);
		
		JTextPane SPORT = new JTextPane();
		SPORT.setEditable(false);
		SPORT.setText(info[8]);
		SPORT.setBounds(504, 150, 123, 22);
		frame.getContentPane().add(SPORT);
		
		JTextPane STAT = new JTextPane();
		STAT.setEditable(false);
		STAT.setText(info[9]);
		STAT.setBounds(504, 66, 123, 22);
		frame.getContentPane().add(STAT);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnClose.setBounds(47, 420, 97, 25);
		frame.getContentPane().add(btnClose);
		
		JTextPane txtpnFirstName = new JTextPane();
		txtpnFirstName.setEditable(false);
		txtpnFirstName.setText("First Name: ");
		txtpnFirstName.setBounds(45, 38, 123, 22);
		frame.getContentPane().add(txtpnFirstName);
		
		JTextPane txtpnLastName = new JTextPane();
		txtpnLastName.setText("Last Name: ");
		txtpnLastName.setEditable(false);
		txtpnLastName.setBounds(219, 38, 123, 22);
		frame.getContentPane().add(txtpnLastName);
		
		JTextPane txtpnStatus = new JTextPane();
		txtpnStatus.setText("Status: ");
		txtpnStatus.setEditable(false);
		txtpnStatus.setBounds(504, 38, 123, 22);
		frame.getContentPane().add(txtpnStatus);
		
		JTextPane txtpnSport = new JTextPane();
		txtpnSport.setText("Sport: ");
		txtpnSport.setEditable(false);
		txtpnSport.setBounds(504, 123, 123, 22);
		frame.getContentPane().add(txtpnSport);
		
		JTextPane txtpnEmail = new JTextPane();
		txtpnEmail.setText("Email: ");
		txtpnEmail.setEditable(false);
		txtpnEmail.setBounds(45, 123, 123, 22);
		frame.getContentPane().add(txtpnEmail);
		
		JTextPane txtpnEmergencyContact = new JTextPane();
		txtpnEmergencyContact.setText("Emergency Contact: ");
		txtpnEmergencyContact.setEditable(false);
		txtpnEmergencyContact.setBounds(45, 216, 197, 22);
		frame.getContentPane().add(txtpnEmergencyContact);
		
		JTextPane txtpnEmergencyContactNumber = new JTextPane();
		txtpnEmergencyContactNumber.setText("Emergency Contact Number: ");
		txtpnEmergencyContactNumber.setEditable(false);
		txtpnEmergencyContactNumber.setBounds(45, 251, 197, 22);
		frame.getContentPane().add(txtpnEmergencyContactNumber);
		
		EC = new JTextPane();
		EC.setEditable(false);
		EC.setText(info[6]);
		EC.setBounds(254, 216, 373, 22);
		frame.getContentPane().add(EC);
		
		ECN = new JTextPane();
		ECN.setEditable(false);
		ECN.setText(info[7]);
		ECN.setBounds(254, 251, 373, 22);
		frame.getContentPane().add(ECN);
		
		JTextPane E = new JTextPane();
		E.setEditable(false);
		E.setText(info[5]);
		E.setBounds(45, 150, 414, 22);
		frame.getContentPane().add(E);
		
		JButton btnAddInjury = new JButton("Add Injury");
		btnAddInjury.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewInjury ni = new NewInjury();
				ni.setVisibility(true);
			}
		});
		btnAddInjury.setBounds(464, 420, 97, 25);
		frame.getContentPane().add(btnAddInjury);
	}
}

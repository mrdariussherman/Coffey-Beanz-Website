package Java.Project.Prototypes;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionListener;

public class HeadTrainerAthletes {

	private JFrame frame;
	private JTextField txtSearch;
	private DefaultListModel<String> as = new DefaultListModel<String>();
	private JComboBox comboBox = new JComboBox();

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HeadTrainerTrainers window = new HeadTrainerTrainers();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public HeadTrainerAthletes() {
		initialize();
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(false); //initially false
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		mntmHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerHome hth = new HeadTrainerHome();
				hth.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmHome);
		
		JMenuItem mntmAthletes = new JMenuItem("Athletes");
		mntmAthletes.setBackground(Color.LIGHT_GRAY);
		mntmAthletes.setSelected(true);
		menuBar.add(mntmAthletes);
		
		JMenuItem mntmTrainers = new JMenuItem("Trainers");
		mntmTrainers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerTrainers htt = new HeadTrainerTrainers();
				htt.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmTrainers);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnTrainers = new JTextPane();
		txtpnTrainers.setEditable(false);
		txtpnTrainers.setText("Athletes");
		txtpnTrainers.setBounds(191, 51, 319, 22);
		frame.getContentPane().add(txtpnTrainers);
		
		txtSearch = new JTextField();
		txtSearch.setText("Search");
		txtSearch.setBounds(532, 13, 116, 22);
		frame.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		comboBox.setBounds(191, 92, 319, 22);
		comboBox.addItem("Football");
		comboBox.addItem("Baseball");
		comboBox.addItem("Basketball");
		comboBox.addItem("Soccer");
		comboBox.addItem("Volleyball");
		comboBox.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			as.clear();
			getAthletes(1);
			}
		});
		frame.getContentPane().add(comboBox);
		getAthletes(2);
		
		JList list = new JList();
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		list.setBounds(191, 143, 319, 295);
		list.setModel(as);
		frame.getContentPane().add(list);
		
		MouseListener ml = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()==2) {
					String name = (String)list.getSelectedValue();
					String[] n = name.split(" ");
					File file = new File("Data.csv");
					try {
						Scanner scan = new Scanner(file);
						while(scan.hasNextLine()) {
							String line = scan.nextLine();
							String[] arr = line.split(",");
							if(arr[0].equals(n[0])) {
								HeadTrainerAthleteProf htap = new HeadTrainerAthleteProf(n[0]);
								htap.setVisibility(true);
								frame.dispose();
							}
						}
						scan.close();
					} catch (FileNotFoundException ef) {
						ef.printStackTrace();
					}					
				}
			}
		};
		list.addMouseListener(ml);
		
		JButton btnNewTrainer = new JButton("New Athlete");
		btnNewTrainer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewAthlete na = new NewAthlete();
				na.setVisibility(true);
				frame.dispose();
			}
		});
		btnNewTrainer.setBounds(532, 238, 134, 25);
		frame.getContentPane().add(btnNewTrainer);
		
		JButton btnNewButton = new JButton("IR/Watchlist");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IRWatchlist irw = new IRWatchlist();
				irw.setVisibility(true);
			}
		});
		btnNewButton.setBounds(532, 188, 134, 23);
		frame.getContentPane().add(btnNewButton);
	}
	
	public void getAthletes(int num) {
		File file = new File("Data.csv");
		as.addElement("");
		try {
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] arr = line.split(",");
				if(num == 1) {	
					if(arr[4].equals("Athlete") && arr[8].equals(comboBox.getItemAt(comboBox.getSelectedIndex()))) {
						as.addElement(arr[0] + " " + arr[1] + " (" + arr[8] + ") - " + arr[9]);
					}
				}
				else {
					//as.removeAllElements();
					if(arr[4].equals("Athlete") && arr[8].equals("Football")) {
						as.addElement(arr[0] + " " + arr[1] + " (" + arr[8] + ") - " + arr[9]);
					}
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}

package Java.Project.Prototypes;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JLabel;

public class HeadTrainerAthleteProf {

	private JFrame frame;
	private JTextPane EC;
	private JTextPane ECN;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlayerHome window = new PlayerHome();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}/*

	/**
	 * Create the application.
	 */
	public HeadTrainerAthleteProf(String name) {
		String[] info = getInfo(name);
		initialize(info);
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}
	
	public String[] getInfo(String name) {
		File file = new File("Data.csv");
		try {
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] arr = line.split(",");
				if(arr[0].equals(name)) {
					return arr;
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String[] info) {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(false); //initially false
		
		/*JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(681, 0, 21, 503);
		frame.getContentPane().add(scrollBar);
		JScrollPane scrollPane = new JScrollPane(frame);
		scrollPane.setPreferredSize(new Dimension(720,550));*/
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		mntmHome.setBackground(Color.LIGHT_GRAY);
		mntmHome.setSelected(true);
		menuBar.add(mntmHome);
		
		JMenuItem mntmMedicalInfo = new JMenuItem("Medical Info");
		mntmMedicalInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlayerMedStuff pms = new PlayerMedStuff(info[0]);
				pms.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmMedicalInfo);
		
		JTextPane FN = new JTextPane();
		FN.setEditable(false);
		FN.setText(info[0]);
		FN.setBounds(45, 66, 123, 22);
		frame.getContentPane().add(FN);
		
		JTextPane LN = new JTextPane();
		LN.setEditable(false);
		LN.setText(info[1]);
		LN.setBounds(219, 66, 123, 22);
		frame.getContentPane().add(LN);
		
		JTextPane SPORT = new JTextPane();
		SPORT.setText(info[8]);
		SPORT.setBounds(504, 150, 123, 22);
		frame.getContentPane().add(SPORT);
		
		JTextPane STAT = new JTextPane();
		STAT.setText(info[9]);
		STAT.setBounds(504, 66, 123, 22);
		frame.getContentPane().add(STAT);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerAthletes hta = new HeadTrainerAthletes();
				hta.setVisibility(true);
				frame.dispose();
			}
		});
		btnClose.setBounds(47, 420, 97, 25);
		frame.getContentPane().add(btnClose);
		
		JTextPane txtpnFirstName = new JTextPane();
		txtpnFirstName.setEditable(false);
		txtpnFirstName.setText("First Name: ");
		txtpnFirstName.setBounds(45, 38, 123, 22);
		frame.getContentPane().add(txtpnFirstName);
		
		JTextPane txtpnLastName = new JTextPane();
		txtpnLastName.setText("Last Name: ");
		txtpnLastName.setEditable(false);
		txtpnLastName.setBounds(219, 38, 123, 22);
		frame.getContentPane().add(txtpnLastName);
		
		JTextPane txtpnStatus = new JTextPane();
		txtpnStatus.setText("Status: ");
		txtpnStatus.setEditable(false);
		txtpnStatus.setBounds(504, 38, 123, 22);
		frame.getContentPane().add(txtpnStatus);
		
		JTextPane txtpnSport = new JTextPane();
		txtpnSport.setText("Sport: ");
		txtpnSport.setEditable(false);
		txtpnSport.setBounds(504, 123, 123, 22);
		frame.getContentPane().add(txtpnSport);
		
		JTextPane txtpnEmail = new JTextPane();
		txtpnEmail.setText("Email: ");
		txtpnEmail.setEditable(false);
		txtpnEmail.setBounds(45, 123, 123, 22);
		frame.getContentPane().add(txtpnEmail);
		
		JTextPane txtpnEmergencyContact = new JTextPane();
		txtpnEmergencyContact.setText("Emergency Contact: ");
		txtpnEmergencyContact.setEditable(false);
		txtpnEmergencyContact.setBounds(45, 216, 197, 22);
		frame.getContentPane().add(txtpnEmergencyContact);
		
		JTextPane txtpnEmergencyContactNumber = new JTextPane();
		txtpnEmergencyContactNumber.setText("Emergency Contact Number: ");
		txtpnEmergencyContactNumber.setEditable(false);
		txtpnEmergencyContactNumber.setBounds(45, 251, 197, 22);
		frame.getContentPane().add(txtpnEmergencyContactNumber);
		
		EC = new JTextPane();
		EC.setText(info[6]);
		EC.setBounds(254, 216, 373, 22);
		frame.getContentPane().add(EC);
		
		ECN = new JTextPane();
		ECN.setText(info[7]);
		ECN.setBounds(254, 251, 373, 22);
		frame.getContentPane().add(ECN);
		
		JTextPane E = new JTextPane();
		E.setText(info[5]);
		E.setBounds(45, 150, 414, 22);
		frame.getContentPane().add(E);
		
		JButton btnAddInjury = new JButton("Add Injury");
		btnAddInjury.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewInjury ni = new NewInjury();
				ni.setVisibility(true);
			}
		});
		btnAddInjury.setBounds(464, 420, 97, 25);
		frame.getContentPane().add(btnAddInjury);
		
		JButton btnEdit = new JButton("Save Edits");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!info[5].equals(E.getText())) {
					info[5] = E.getText();
				}
				if(!info[6].equals(EC.getText())) {
					info[6] = EC.getText();
				}
				if(!info[7].equals(ECN.getText())) {
					info[7] = ECN.getText();
				}
				if(!info[8].equals(SPORT.getText())) {
					info[8] = SPORT.getText();
				}
				if(!info[9].equals(STAT.getText())) {
					info[9] = STAT.getText();
				}
				File file = new File("Data.csv");
				try {
					Scanner scan = new Scanner(file);
					String out1 = "";
					String out2 = "";
					boolean flag = false;
					while(scan.hasNextLine()) {
						String line = scan.nextLine();
						String arr[] = line.split(",");
						if(!arr[0].equals(info[0]) && !flag) {
							out1 += line;
							out1 += "\n";
						}
						else {
							flag = true;
						}
						if(!arr[0].equals(info[0]) && flag) {
							out2 += line;
							out2 += "\n";
						}
					}
					scan.close();
					FileWriter fw = new FileWriter(file);
					String out3 = info[0] + "," + info[1] + "," + info[2] + "," + info[3] + "," + 
					info[4] + "," + info[5] + "," + info[6] + "," + info [7] + "," + info[8] + "," +
					info[9] + "," + info[10] + "\n";
					out1 += out3;
					out1 += out2;
					fw.write(out1);
					fw.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnEdit.setBounds(267, 420, 97, 25);
		frame.getContentPane().add(btnEdit);
	}
}

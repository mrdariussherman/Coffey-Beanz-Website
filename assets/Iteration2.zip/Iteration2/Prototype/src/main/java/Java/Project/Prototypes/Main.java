package Java.Project.Prototypes;

import java.awt.EventQueue;

import javax.swing.JFrame;

public class Main {

	private JFrame frame;
	private static Login login = new Login();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login.setVisibility(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}

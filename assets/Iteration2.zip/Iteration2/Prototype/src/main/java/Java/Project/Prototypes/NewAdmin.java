package Java.Project.Prototypes;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class NewAdmin {

	private JFrame frame;
	private JTextField FN;
	private JTextField LN;
	private JTextField UN;
	private JPasswordField PWD;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewTrainer window = new NewTrainer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}/*

	/**
	 * Create the application.
	 */
	public NewAdmin() {
		initialize();
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(false); //initially false
		
		JTextPane txtpnNewTrainer = new JTextPane();
		txtpnNewTrainer.setEditable(false);
		txtpnNewTrainer.setText("New Admin");
		txtpnNewTrainer.setBounds(308, 39, 85, 22);
		frame.getContentPane().add(txtpnNewTrainer);
		
		JTextPane txtpnFirstName = new JTextPane();
		txtpnFirstName.setEditable(false);
		txtpnFirstName.setText("First Name:");
		txtpnFirstName.setBounds(127, 105, 146, 22);
		frame.getContentPane().add(txtpnFirstName);
		
		FN = new JTextField();
		FN.setBounds(308, 105, 269, 22);
		frame.getContentPane().add(FN);
		FN.setColumns(10);
		
		JTextPane txtpnLastName = new JTextPane();
		txtpnLastName.setEditable(false);
		txtpnLastName.setText("Last Name: ");
		txtpnLastName.setBounds(127, 138, 146, 22);
		frame.getContentPane().add(txtpnLastName);
		
		JTextPane txtpnEmail = new JTextPane();
		txtpnEmail.setEditable(false);
		txtpnEmail.setText("Username: ");
		txtpnEmail.setBounds(127, 171, 146, 22);
		frame.getContentPane().add(txtpnEmail);
		
		JTextPane txtpnPassword = new JTextPane();
		txtpnPassword.setEditable(false);
		txtpnPassword.setText("Password: ");
		txtpnPassword.setBounds(127, 204, 146, 22);
		frame.getContentPane().add(txtpnPassword);
		
		LN = new JTextField();
		LN.setBounds(308, 138, 269, 22);
		frame.getContentPane().add(LN);
		LN.setColumns(10);
		
		UN = new JTextField();
		UN.setBounds(308, 171, 269, 22);
		frame.getContentPane().add(UN);
		UN.setColumns(10);
		
		PWD = new JPasswordField();
		PWD.setBounds(308, 204, 269, 22);
		frame.getContentPane().add(PWD);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = new File("Data.csv");
				String out = "";
				Scanner scan;
				try {
					scan = new Scanner(file);
					while(scan.hasNextLine()) {
						out += scan.nextLine();
						out += "\n";
					}
					out += FN.getText() + ",";
					out += LN.getText() + ",";
					out += UN.getText() + ",";
					out += PWD.getText() + ",";
					out += "Admin\n";
					scan.close();
					FileWriter f;
					try {
						f = new FileWriter(file);
						f.write(out);
						f.flush();
						f.close();	
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}				
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				HeadTrainerHome hth = new HeadTrainerHome();
				hth.setVisibility(true);
				frame.dispose();
			}
		});
		btnSubmit.setBounds(210, 390, 97, 25);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerHome hth = new HeadTrainerHome();
				hth.setVisibility(true);
				frame.dispose();
			}
		});
		btnCancel.setBounds(394, 390, 97, 25);
		frame.getContentPane().add(btnCancel);
		
	}

}

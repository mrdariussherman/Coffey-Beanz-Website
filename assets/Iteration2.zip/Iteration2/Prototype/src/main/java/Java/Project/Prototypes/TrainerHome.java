package Java.Project.Prototypes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JTextField;

public class TrainerHome {

	private JFrame frame;
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the application.
	 */
	public TrainerHome(String name) {
		initialize(name);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String name) {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		mntmHome.setBackground(Color.LIGHT_GRAY);
		mntmHome.setSelected(true);
		menuBar.add(mntmHome);
		
		JMenuItem mntmAthletes = new JMenuItem("Athletes");
		menuBar.add(mntmAthletes);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnFirstName = new JTextPane();
		txtpnFirstName.setEditable(false);
		txtpnFirstName.setText("First Name");
		txtpnFirstName.setBounds(31, 13, 84, 22);
		frame.getContentPane().add(txtpnFirstName);
		
		JTextPane txtpnLastName = new JTextPane();
		txtpnLastName.setEditable(false);
		txtpnLastName.setText("Last Name");
		txtpnLastName.setBounds(127, 13, 84, 22);
		frame.getContentPane().add(txtpnLastName);
		
		JTextPane txtpnAthletesResponsibleFor = new JTextPane();
		txtpnAthletesResponsibleFor.setText("Athletes Responsible For: ");
		txtpnAthletesResponsibleFor.setBounds(127, 99, 214, 22);
		frame.getContentPane().add(txtpnAthletesResponsibleFor);
		
		JList list = new JList();
		list.setBounds(127, 147, 460, 257);
		frame.getContentPane().add(list);
		
		txtSearch = new JTextField();
		txtSearch.setText("Search");
		txtSearch.setBounds(471, 13, 116, 22);
		frame.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
	}
	
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}
}

package Java.Project.Prototypes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class NewInjury {

	private JFrame frame;
	private JTextField txttext;
	private JTextField txtTreatment;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewInjury window = new NewInjury();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public NewInjury() {
		initialize();
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(false); //initially false
		
		JTextPane txtpnNewInjury = new JTextPane();
		txtpnNewInjury.setEditable(false);
		txtpnNewInjury.setBounds(314, 39, 74, 22);
		txtpnNewInjury.setText("New Injury");
		frame.getContentPane().add(txtpnNewInjury);
		
		JTextPane txtpnInjuryName = new JTextPane();
		txtpnInjuryName.setEditable(false);
		txtpnInjuryName.setText("Injury Name: ");
		txtpnInjuryName.setBounds(95, 86, 186, 22);
		frame.getContentPane().add(txtpnInjuryName);
		
		txttext = new JTextField();
		txttext.setBounds(308, 86, 289, 22);
		frame.getContentPane().add(txttext);
		txttext.setColumns(10);
		
		JTextPane txtpnInjuryDescription = new JTextPane();
		txtpnInjuryDescription.setEditable(false);
		txtpnInjuryDescription.setText("Injury Description: ");
		txtpnInjuryDescription.setBounds(95, 121, 186, 22);
		frame.getContentPane().add(txtpnInjuryDescription);
		
		JTextArea input = new JTextArea();
		input.setEditable(false);
		input.setBounds(95, 156, 502, 70);
		MouseListener ml = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if(e.getClickCount()==2) {
					input.setEditable(true);
				}
			}
		};
		input.addMouseListener(ml);
		frame.getContentPane().add(input);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnSubmit.setBounds(184, 441, 97, 25);
		frame.getContentPane().add(btnSubmit);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnCancel.setBounds(380, 441, 97, 25);
		frame.getContentPane().add(btnCancel);
		
		txtTreatment = new JTextField();
		txtTreatment.setEditable(false);
		txtTreatment.setText("Treatment:");
		txtTreatment.setBounds(95, 239, 116, 22);
		frame.getContentPane().add(txtTreatment);
		txtTreatment.setColumns(10);
		
		textField = new JTextField();
		textField.setBounds(95, 274, 502, 103);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
	}
}

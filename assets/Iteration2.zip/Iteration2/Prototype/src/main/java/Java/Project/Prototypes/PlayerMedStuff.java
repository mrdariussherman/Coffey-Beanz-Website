package Java.Project.Prototypes;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.Color;

public class PlayerMedStuff {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PlayerHome window = new PlayerHome();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}/*

	/**
	 * Create the application.
	 */
	public PlayerMedStuff(String name) {
		String[] info = getInfo(name);
		initialize(info);
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}
	
	public String[] getInfo(String name) {
		File file = new File("Data.csv");
		try {
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] arr = line.split(",");
				if(arr[0].equals(name)) {
					return arr;
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String[] info) {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(false); //initially false
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		mntmHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerAthleteProf htap = new HeadTrainerAthleteProf(info[0]);
				htap.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmHome);
		
		JMenuItem mntmMedicalInfo = new JMenuItem("Medical Info");
		mntmMedicalInfo.setBackground(Color.LIGHT_GRAY);
		mntmMedicalInfo.setSelected(true);
		menuBar.add(mntmMedicalInfo);
		
		JTextPane txtpnImportantNotes = new JTextPane();
		txtpnImportantNotes.setEditable(false);
		txtpnImportantNotes.setText("Important Notes: ");
		txtpnImportantNotes.setBounds(45, 25, 164, 22);
		frame.getContentPane().add(txtpnImportantNotes);
		
		JTextArea txtrtext = new JTextArea();
		txtrtext.setEditable(false);
		txtrtext.setBounds(221, 25, 431, 49);
		frame.getContentPane().add(txtrtext);
		
		JTextPane txtpnCurrentInjuries = new JTextPane();
		txtpnCurrentInjuries.setEditable(false);
		txtpnCurrentInjuries.setText("Current Injuries: ");
		txtpnCurrentInjuries.setBounds(45, 87, 164, 22);
		frame.getContentPane().add(txtpnCurrentInjuries);
		
		JTextArea txtrtext_1 = new JTextArea();
		txtrtext_1.setEditable(false);
		txtrtext_1.setBounds(221, 87, 431, 78);
		frame.getContentPane().add(txtrtext_1);
		
		JTextPane txtpnPastInjuries = new JTextPane();
		txtpnPastInjuries.setEditable(false);
		txtpnPastInjuries.setText("Past Injuries: ");
		txtpnPastInjuries.setBounds(45, 178, 166, 22);
		frame.getContentPane().add(txtpnPastInjuries);
		
		JTextArea txtrtext_2 = new JTextArea();
		txtrtext_2.setEditable(false);
		txtrtext_2.setBounds(221, 178, 431, 136);
		frame.getContentPane().add(txtrtext_2);
		
		JTextPane txtpnMedicalHistory = new JTextPane();
		txtpnMedicalHistory.setEditable(false);
		txtpnMedicalHistory.setText("Medical History");
		txtpnMedicalHistory.setBounds(45, 327, 164, 22);
		frame.getContentPane().add(txtpnMedicalHistory);
		
		JTextArea txtrtext_3 = new JTextArea();
		txtrtext_3.setEditable(false);
		txtrtext_3.setText(info[10]);
		txtrtext_3.setBounds(221, 327, 431, 91);
		frame.getContentPane().add(txtrtext_3);
	}
}

package Java.Project.Prototypes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frame;
	private JTextField textUsername;
	private JPasswordField textPassword;
	private String status = "";
	private String name = "";


	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}
	
	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setVisible(false); //initially false
		
		JTextPane txtpnOsmir = new JTextPane();
		txtpnOsmir.setText("OSMIR");
		txtpnOsmir.setBounds(325, 85, 52, 22);
		txtpnOsmir.setEditable(false);
		frame.getContentPane().add(txtpnOsmir);
		
		JTextPane txtpnUsername = new JTextPane();
		txtpnUsername.setText("Username: ");
		txtpnUsername.setBounds(164, 152, 149, 22);
		txtpnUsername.setEditable(false);
		frame.getContentPane().add(txtpnUsername);
		
		textUsername = new JTextField();
		textUsername.setBounds(325, 152, 254, 22);
		frame.getContentPane().add(textUsername);
		textUsername.setColumns(10);
		
		JTextPane txtpnPassword = new JTextPane();
		txtpnPassword.setText("Password: ");
		txtpnPassword.setBounds(164, 202, 149, 22);
		txtpnPassword.setEditable(false);
		frame.getContentPane().add(txtpnPassword);
		
		textPassword = new JPasswordField();
		textPassword.setBounds(325, 202, 254, 22);
		frame.getContentPane().add(textPassword);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				File file = new File("Data.csv");
				Athlete a = new Athlete();
				try {
					Scanner scan = new Scanner(file);
					while(scan.hasNextLine()) {
						String line = scan.nextLine();
						String[] arr = line.split(",");
						if(textUsername.getText().equals(arr[2]) && textPassword.getText().equals(arr[3])) {
							name = arr[0];
							status = arr[4];
							break;
						}
					}
					scan.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				}
				switch(status) {
				case "Admin":
					HeadTrainerHome hth = new HeadTrainerHome();
					hth.setVisibility(true);
					frame.dispose();
					break;
				case "Trainer":
					TrainerHome th = new TrainerHome(name);
					th.setVisibility(true);
					frame.dispose();
					break;
				case "Athlete":
					PlayerHome ph = new PlayerHome(name);
					ph.setVisibility(true);
					frame.dispose();
					break;
				default:
					textUsername.setText("");
					textPassword.setText("");
					break;
				}
			}
		});
		btnSubmit.setBounds(303, 297, 97, 25);
		frame.getContentPane().add(btnSubmit);
	}

}

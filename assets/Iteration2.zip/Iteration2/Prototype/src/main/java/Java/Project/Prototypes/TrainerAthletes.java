package Java.Project.Prototypes;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JButton;

public class TrainerAthletes {

	private JFrame frame;
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TrainerAthletes window = new TrainerAthletes();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public TrainerAthletes() {
		initialize();
	}

	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(false); //initially false
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		menuBar.add(mntmHome);
		
		JMenuItem mntmAthletes = new JMenuItem("Athletes");
		menuBar.add(mntmAthletes);
		
		JMenuItem mntmTrainers = new JMenuItem("Trainers");
		menuBar.add(mntmTrainers);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnAthletes = new JTextPane();
		txtpnAthletes.setText("Athletes");
		txtpnAthletes.setBounds(191, 51, 319, 22);
		frame.getContentPane().add(txtpnAthletes);
		
		txtSearch = new JTextField();
		txtSearch.setText("Search");
		txtSearch.setBounds(532, 13, 116, 22);
		frame.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(191, 92, 319, 22);
		frame.getContentPane().add(comboBox);
		
		JList list = new JList();
		list.setBounds(191, 143, 319, 295);
		frame.getContentPane().add(list);
		
		JButton btnIrWatch = new JButton("IR & Watch List");
		btnIrWatch.setBounds(532, 238, 134, 25);
		frame.getContentPane().add(btnIrWatch);
	}
}

package Java.Project.Prototypes;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.Color;

public class HeadTrainerHome {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HeadTrainerHome window = new HeadTrainerHome();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public HeadTrainerHome() {
		initialize();
	}
	
	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(false); //initially false
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		mntmHome.setBackground(Color.LIGHT_GRAY);
		mntmHome.setSelected(true);
		menuBar.add(mntmHome);
		
		JMenuItem mntmAthletes = new JMenuItem("Athletes");
		mntmAthletes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerAthletes hta = new HeadTrainerAthletes();
				hta.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmAthletes);
		
		JMenuItem mntmTrainers = new JMenuItem("Trainers");
		mntmTrainers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerTrainers htt = new HeadTrainerTrainers();
				htt.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmTrainers);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnWelcome = new JTextPane();
		txtpnWelcome.setEditable(false);
		txtpnWelcome.setText("WELCOME");
		txtpnWelcome.setBounds(111, 80, 508, 77);
		frame.getContentPane().add(txtpnWelcome);
		
		JButton btnNewUser = new JButton("New User");
		btnNewUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NewAdmin na = new NewAdmin();
				na.setVisibility(true);
				frame.dispose();
			}
		});
		btnNewUser.setBounds(190, 270, 89, 23);
		frame.getContentPane().add(btnNewUser);
		
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
			}
		});
		btnClose.setBounds(419, 269, 97, 25);
		frame.getContentPane().add(btnClose);
	}
}

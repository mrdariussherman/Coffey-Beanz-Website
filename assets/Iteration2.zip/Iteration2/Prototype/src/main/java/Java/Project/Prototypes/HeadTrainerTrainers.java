package Java.Project.Prototypes;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextPane;
import javax.swing.JTextField;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.Color;

public class HeadTrainerTrainers {

	private JFrame frame;
	private JTextField txtSearch;
	private DefaultListModel<String> ts = new DefaultListModel<String>();

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HeadTrainerTrainers window = new HeadTrainerTrainers();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the application.
	 */
	public HeadTrainerTrainers() {
		getTrainers();
		initialize();
	}

	public void getTrainers() {
		File file = new File("Data.csv");
		ts.addElement("");
		try {
			Scanner scan = new Scanner(file);
			while(scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] arr = line.split(",");
				if(arr[4].equals("Trainer")) {
					ts.addElement(arr[0] + " " + arr[1] + " (" + arr[6] + ")");
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Set visibility
	 */
	public void setVisibility(boolean flag) {
		frame.setVisible(flag);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 550);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(false); //initially false
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenuItem mntmHome = new JMenuItem("Home");
		mntmHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerHome hth = new HeadTrainerHome();
				hth.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmHome);
		
		JMenuItem mntmAthletes = new JMenuItem("Athletes");
		mntmAthletes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HeadTrainerAthletes hta = new HeadTrainerAthletes();
				hta.setVisibility(true);
				frame.dispose();
			}
		});
		menuBar.add(mntmAthletes);
		
		JMenuItem mntmTrainers = new JMenuItem("Trainers");
		mntmTrainers.setBackground(Color.LIGHT_GRAY);
		mntmTrainers.setSelected(true);
		menuBar.add(mntmTrainers);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnTrainers = new JTextPane();
		txtpnTrainers.setEditable(false);
		txtpnTrainers.setText("Trainers");
		txtpnTrainers.setBounds(191, 51, 319, 22);
		frame.getContentPane().add(txtpnTrainers);
		
		txtSearch = new JTextField();
		txtSearch.setText("Search");
		txtSearch.setBounds(532, 13, 116, 22);
		frame.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(191, 92, 319, 22);
		comboBox.addItem("Football");
		comboBox.addItem("Baseball");
		comboBox.addItem("Basketball");
		comboBox.addItem("Soccer");
		comboBox.addItem("Volleyball");
		frame.getContentPane().add(comboBox);
		
		JList list = new JList();
		list.setBounds(191, 143, 319, 295);
		list.setModel(ts);
		frame.getContentPane().add(list);
		
		JButton btnNewTrainer = new JButton("New Trainer");
		btnNewTrainer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewTrainer nt = new NewTrainer();
				nt.setVisibility(true);
				frame.dispose();
			}
		});
		btnNewTrainer.setBounds(532, 238, 134, 25);
		frame.getContentPane().add(btnNewTrainer);
	}

}
